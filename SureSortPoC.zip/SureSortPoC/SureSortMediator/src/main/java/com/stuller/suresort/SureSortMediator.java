package com.stuller.suresort;

import java.io.*;
import java.net.Socket;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;

public class SureSortMediator extends AbstractMediator {

	public boolean mediate(MessageContext context) {

		String SocketPayload = (String) context.getProperty("SocketPayload");
		String InQueue = (String) context.getProperty("InQueue");
		String SSName = (String) context.getProperty("SSName");
		String ActiveMQConnection = "tcp://" + (String) context.getProperty("ActiveMQConnection");
		
		trace.trace("SocketPayload : " + context.getProperty("SocketPayload").toString());
		//String InQueue = "SureSort01";   ********
		//String SSName = "OPEXSureSort01";  ********
		//String SSName = "carservertest"; 
		  
		
		log.info("Version SureSortMediator : In Java block Step 1.1 : SocketPayload is :" + SocketPayload);
		log.info("* * * Connecting" + InQueue + " to " + SSName + ":24200 * * *");
		Socket ELCSocket = null;
		PrintWriter out = null;
		try {
			// Create a MQ ConnectionFactory
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
					ActiveMQConnection);
			//		"tcp://wso2mqdev.stuller.laf:61616");  *******

			// Create a MQ Connection
			Connection connection = connectionFactory.createConnection();
			connection.start();

			// Create a MQ Session
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			// Create the MQ destination (Topic or Queue)
			Destination destination = session.createQueue(InQueue);

			// Create a MQ MessageConsumer from the Session to the Topic or Queue
			MessageConsumer consumer = session.createConsumer(destination);

			try {
				// Create the Socket connection to ELC 
				//ELCSocket = new Socket("OPEXSureSort01", 24200);
				ELCSocket = new Socket(SSName, 24200);
				out = new PrintWriter(ELCSocket.getOutputStream(), true);
				DataInputStream dis = new DataInputStream(ELCSocket.getInputStream());
				DataOutputStream dos = new DataOutputStream(ELCSocket.getOutputStream());
                
				// Create ELC message boundary control characters - ETX, STX
				int STX = 2, ETX = 3;
				String stx = new Character((char) STX).toString();
				String etx = new Character((char) ETX).toString();
				String ResponseMessage1 = null;
				String ResponseMessage2 = null;

				out.println(stx + SocketPayload + etx);
				log.info(  InQueue + " to " + SSName + ": TX -- ELCserver SureSortMediator: " + stx + SocketPayload + etx);

				while (true) {

					if (ELCSocket.isClosed()) {
						log.info( InQueue + " to " + SSName + ": - ELC Server WebSocket closed! SureSortMediator -- ");
						break;
					}

					if (dis.available() > 1) {

						String RxMessage = dis.readLine();
						log.info(InQueue + " to " + SSName + ":  -  RX -- ELCserver SureSortMediator: " + RxMessage);
						if (RxMessage.contains("RoutingRequest")) {
							//log.info("RoutingRequest from ELC SureSortMediator .... ");
							ResponseMessage1 = stx + ELCInboundMessageProcess(RxMessage) + etx;
						}
						else if(RxMessage.contains("ItemDelivered")) {
                            ItemDeliveredMessageProcess(RxMessage);
						}
					} 
					else
					{
						Message message = consumer.receiveNoWait();

						if (message != null) {
							TextMessage textMessage = (TextMessage) message;

							if (textMessage.getText().contains("bye")) {
								log.info(InQueue + " to " + SSName + ": Received BYE message from JMS SureSortMediator....");
								//log.info(InQueue + " to " + SSName + ": !!Closing ELC Server WebSocket connection SureSortMediator....");
								break;
							}

							ResponseMessage2 = stx + textMessage.getText() + etx;
							//log.info(InQueue + " to " + SSName + ": JMS Message Received for SureSort SureSortMediator :" + ResponseMessage2);
						}
					}
					Thread.sleep(10);
					/*if (ResponseMessage1 != null) {
						log.info(InQueue + " to " + SSName + ": TX -- ELCserver SureSortMediator: " + ResponseMessage1);
					}
					if (ResponseMessage2 != null) {
						log.info(InQueue + " to " + SSName + ": TX -- ELCserver SureSortMediator: " + ResponseMessage2);
					}*/
					if (ResponseMessage1 != null || ResponseMessage2 != null) {
						out.println(ResponseMessage1 + ResponseMessage2);
						if  (out.checkError())
						{
							log.info(InQueue + " to " + SSName + ": Broken Socket connection SureSortMediator....");
							log.info(InQueue + " to " + SSName + ": !!Closing ELC Server WebSocket connection from SureSortMediator....");
							break;							
						};	
					}
					ResponseMessage1 = null;
					ResponseMessage2 = null;
				}
				session.close();
				connection.close();
				dos.close();
				dis.close();
				ELCSocket.close();

			} catch (Exception e) {
				session.close();
				connection.close();
				ELCSocket.close();
				e.printStackTrace();
				log.error(InQueue + " to " + SSName + ":  !!!!!! Exception1 e in SureSortMediator.Mediate !!!!! " + e.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(InQueue + " to " + SSName + ":  !!!!!! Exception2 e in SureSortMediator.Mediate !!!!! " + e.toString());
		}
		return true;
	}

	public String ELCInboundMessageProcess(String RxMessage) {
		String TxMessage = null;
		RxMessage = RxMessage.replaceAll("\\p{Cntrl}", "");
		String strURL = "http://localhost:8280/SureSortFetchBinID/api";
		PostMethod postMethod = new PostMethod(strURL);
		try {
			postMethod.setRequestEntity(new StringRequestEntity(RxMessage, "text/custom", "UTF-8"));
			HttpClient httpClient = new HttpClient();
			int result = httpClient.executeMethod(null, postMethod);
			//log.info("SureSort Sortation Rest API invoke result SureSortMediator: " + result);
			TxMessage = postMethod.getResponseBodyAsString();
		} catch (Throwable t) {
			log.error("!!!!!!!!!!Error in SureSortMediator.ELCInboundMessageProcess(): " + t.getMessage());
			t.printStackTrace();
		}
		return TxMessage;
	}

	public void ItemDeliveredMessageProcess(String RxMessage) {
		RxMessage = RxMessage.replaceAll("\\p{Cntrl}", "");
		String strURL = "http://localhost:8280/SureSortItemDeliveredEnque/api";
		PostMethod postMethod = new PostMethod(strURL);
		try {
			postMethod.setRequestEntity(new StringRequestEntity(RxMessage, "application/json", "UTF-8"));
			HttpClient httpClient = new HttpClient();
			int result = httpClient.executeMethod(null, postMethod);
			//log.info("SureSort ItemDeliveredMessageProcess Rest API invoke result SureSortMediator: " + result);
		} catch (Throwable t) {
			log.error("!!!!!!!!!!Error in SureSortMediator.ItemDeliveredMessageProcess(): " + t.getMessage());
			t.printStackTrace();
		}
	}	

}
